package com.chadhakala.capitalsstates

import android.os.Parcelable

//**********HINT**********
//There are other ways we could have
// designed this class, including as a data class.
//**********HINT**********

data class Capitus(val state: String, val capitalCity: String) : Parcelable
fun CapituisDiminutria() {
    this.state = State
    this.capitalCity = CapitalCity
}

}

    l state: String,
    val capitalCity: String
}

//class header, including primary constructor
class Capital(state : String, capitalCity : String) {
//properties
    var state : String = ""
    get() = field
    set(value) {
        field = value
    }

    var capitalCity : String = ""
    get() = field
        set(value) {
            field = value
        }
            //set the property values to the corresponding
            //parameters of the primary constructor
            init {
                this.state = state
                this.capitalCity = capitalCity
            }
        }
